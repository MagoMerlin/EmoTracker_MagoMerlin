MagoMerlin Official Packages for EmoTracker
Final Fantasy IV Free Enterprise tracker:

-Now with a Map Tracker! Enjoy.

-This package is designed to be a chars, items, bosses, and locations tracker.

-It's based off of some existing trackers: (http://schala-kitty.net/ff4fe-tracker/) and (https://akw5013.gitlab.io/ffiv-free-enterprise-tracker/).

-You can generate your FFIVFE ROMHack: (http://ff4-free-enterprise.com/).

Note: I have not finished the auto tracker yet. It will take a long time, but I will conclude it someday.

-FFIVFE TrackeR REQUIRES EmoTracker to work, as they are addon packages to the tracker program: (https://emotracker.net/).

All the packages are made by MagoMerlin and designed to be a extremely simple, both visually and functionally, though others have helped contribute via suggestions, codes or sprite links. 

Thanks to EmoSaru, SchalaKitty, Jaysee87, Alex Wolff and MetalMachine.