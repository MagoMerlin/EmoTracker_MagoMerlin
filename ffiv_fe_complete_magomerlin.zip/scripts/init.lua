Tracker:AddItems("standart/items.json")
Tracker:AddMaps("maps/maps.json")
Tracker:AddLocations("locations/checks.json")
Tracker:AddLayouts("standart/tracker_layout.json")
Tracker:AddLayouts("standart/broadcast_layout.json")
if (string.find(Tracker.ActiveVariantUID, "standart_map")) then
    ScriptHost:LoadScript("scripts/logic_common.lua")
end
