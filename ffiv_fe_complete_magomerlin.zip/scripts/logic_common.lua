function canHookLocations()
	if Tracker:ProviderCountForCode("hookcheck") > 0 then
        return Tracker:ProviderCountForCode("eblancolor")
    end
end