--  Load configuration options up front
ScriptHost:LoadScript("scripts/settings.lua")

Tracker:AddItems("items/items.json")
Tracker:AddLocations("locations/locations.json")
Tracker:AddMaps("maps/maps.json")

Tracker:AddLayouts("standart/tracker_layout.json")
Tracker:AddLayouts("standart/broadcast_layout.json")

if (string.find(Tracker.ActiveVariantUID, "standart_map")) then
    ScriptHost:LoadScript("scripts/logic_common.lua")
    Tracker:AddLayouts("standart_map/tracker_layout.json")
	Tracker:AddLayouts("standart_map/broadcast_layout.json")
	Tracker:AddLocations("locations/locations.json")
	Tracker:AddMaps("maps/maps.json")
    if (string.find(Tracker.ActiveVariantUID, "standart_local")) then
    	Tracker:AddLayouts("standart_local/tracker_layout.json")
		Tracker:AddLayouts("standart_local/broadcast_layout.json")
	end
end
if _VERSION == "Lua 5.3" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
else    
    print("Auto-tracker is unsupported by your tracker version")
end