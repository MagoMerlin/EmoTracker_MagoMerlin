--  Load configuration options up front
ScriptHost:LoadScript("scripts/settings.lua")

Tracker:AddItems("items/items.json")

Tracker:AddLayouts("standart/tracker_layout.json")
Tracker:AddLayouts("standart/broadcast_layout.json")

Tracker:AddLocations("locations/locations.json")
Tracker:AddMaps("maps/maps.json")

-- if (string.find(Tracker.ActiveVariantUID, "standart_map")) then
--    ScriptHost:LoadScript("scripts/logic_common.lua")
-- end
if _VERSION == "Lua 5.3" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
else    
    print("Auto-tracker is unsupported by your tracker version")
end