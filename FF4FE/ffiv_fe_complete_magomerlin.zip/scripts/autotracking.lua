-- Configuration --------------------------------------
AUTOTRACKER_ENABLE_DEBUG_LOGGING = true
-------------------------------------------------------

print("")
print("Active Auto-Tracker Configuration")
print("---------------------------------------------------------------------")
print("Enable Item Tracking:        ", AUTOTRACKER_ENABLE_ITEM_TRACKING)
if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
    print("Enable Debug Logging:        ", "true")
end
print("---------------------------------------------------------------------")
print("")

function autotracker_started()
    -- Invoked when the auto-tracker is activated/connected
end

U8_READ_CACHE = 0
U8_READ_CACHE_ADDRESS = 0

U16_READ_CACHE = 0
U16_READ_CACHE_ADDRESS = 0

function InvalidateReadCaches()
    U8_READ_CACHE_ADDRESS = 0
    U16_READ_CACHE_ADDRESS = 0
end

function ReadU8(segment, address)
    if U8_READ_CACHE_ADDRESS ~= address then
        U8_READ_CACHE = segment:ReadUInt8(address)
        U8_READ_CACHE_ADDRESS = address        
    end

    return U8_READ_CACHE
end

function ReadU16(segment, address)
    if U16_READ_CACHE_ADDRESS ~= address then
        U16_READ_CACHE = segment:ReadUInt16(address)
        U16_READ_CACHE_ADDRESS = address        
    end

    return U16_READ_CACHE
end

function updateToggleItemFromByteAndFlag(segment, code, address, flag)
    local item = Tracker:FindObjectForCode(code)
    if item then
        local value = ReadU8(segment, address)
        if AUTOTRACKER_ENABLE_DEBUG_LOGGING then
            print(item.Name, code, flag)
        end

        local flagTest = value & flag

        if flagTest ~= 0 then
            item.Active = true
        else
            item.Active = false
        end
    end
end

function updateKeyItems(segment)

    InvalidateReadCaches()

    if AUTOTRACKER_ENABLE_ITEM_TRACKING then
        updateToggleItemFromByteAndFlag(segment, "Package",  0x7e1500, 0x01)
        updateToggleItemFromByteAndFlag(segment, "Sand Ruby", 0x7e1500, 0x02)
        updateToggleItemFromByteAndFlag(segment, "Legend Sword",   0x7e1500, 0x04)
        updateToggleItemFromByteAndFlag(segment, "Baron Key",    0x7e1500, 0x08)
        updateToggleItemFromByteAndFlag(segment, "Twin Harp",     0x7e1500, 0x10)
        updateToggleItemFromByteAndFlag(segment, "Earth Crystal",    0x7e1500, 0x20)
        updateToggleItemFromByteAndFlag(segment, "Magma Key",    0x7e1500, 0x40)
        updateToggleItemFromByteAndFlag(segment, "Tower Key",    0x7e1500, 0x80)
		updateToggleItemFromByteAndFlag(segment, "Hook",     0x7e1501, 0x01)
		updateToggleItemFromByteAndFlag(segment, "Luca Key",     0x7e1501, 0x02)
        updateToggleItemFromByteAndFlag(segment, "Darkness Crystal", 0x7e1501, 0x04)
        updateToggleItemFromByteAndFlag(segment, "Rat Tail",      0x7e1501, 0x08)
		updateToggleItemFromByteAndFlag(segment, "Adamant",  0x7e1501, 0x10)	
		updateToggleItemFromByteAndFlag(segment, "Pan",      0x7e1501, 0x20)
		updateToggleItemFromByteAndFlag(segment, "Spoon",    0x7e1501, 0x40)
		updateToggleItemFromByteAndFlag(segment, "Pink Tail",     0x7e1501, 0x80)
		updateToggleItemFromByteAndFlag(segment, "Crystal",  0x7e1502, 0x01)
    end
end

-- Run the in-game status check more frequently (every 250ms) to catch save/quit scenarios more effectively
ScriptHost:AddMemoryWatch("FF4FE Key Items", 0x7e1500, 3, updateKeyItems)