The Legend of Zelda Randomizer tracker:

-This package is designed to be a item tracker, maybe a map tracker in the future.

-It's based off of some existing tracker made by MetalMachine in EmoTracker.

-You can download the program and generate your own TLOZR ROMhack: (https://sites.google.com/site/zeldarandomizer/).

-TLOZR Tracker REQUIRES EmoTracker to work, as it is an additional package to the tracker program: (https://emotracker.net/).

This package is made by MagoMerlin and designed to be a extremely simple, both visually and functionally, 
though others have helped contribute via suggestions, codes or sprite links. 
Thanks to Emosaru and MetalMachine.